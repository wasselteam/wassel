import{l as o,a as r}from"../chunks/C-VY9n6g.js";export{o as load_css,r as start};
