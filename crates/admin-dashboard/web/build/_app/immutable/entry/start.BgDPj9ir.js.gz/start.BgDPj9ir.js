import{l as o,a as r}from"../chunks/uDC-R0Nw.js";export{o as load_css,r as start};
